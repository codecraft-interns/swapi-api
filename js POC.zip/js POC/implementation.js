((window, document, undefined) => {
  window.load = function () {
    let index = 0;
    let currentCategory = 'people';
    const firstLabel = document.getElementById('first-label');
    const secondLabel = document.getElementById('second-label');
    const thirdLabel = document.getElementById('third-label');
    const fourthLabel = document.getElementById('fourth-label');

    const firstAttribute = document.getElementById('first-attribute');
    const secondAttribute = document.getElementById('second-attribute');
    const thirdAttribute = document.getElementById('third-attribute');
    const fourthAttribute = document.getElementById('fourth-attribute');

    const nextBtn = document.getElementById('next-btn');
    const prevBtn = document.getElementById('prev-btn');


    const peopleCategory = document.getElementById('people-category');
    const planetCategory = document.getElementById('planet-category');
    const speciesCategory = document.getElementById('species-category');

    const swapiAPI = (category, index = 1) => `https://swapi.co/api/${category}/${index}/?format=json`;


    function getRecord(category, index = 1) {
      return fetch(swapiAPI(category, index)).then(data => data.json());
    }

    const keyValueMap = {
      people: [
        { key: 'name', label: 'Name' },
        { key: 'height', label: 'Height' },
        { key: 'gender', label: 'Gender' },
        { key: 'skin_color', label: 'Skin color' }
      ],
      planets: [
        { key: 'name', label: 'Name' },
        { key: 'diameter', label: 'Diameter' },
        { key: 'climate', label: 'Climate' },
        { key: 'gravity', label: 'Gravity' }
      ],
      sepcies: [
        { key: 'name', label: 'Name' },
        { key: 'height', label: 'Height' },
        { key: 'classification', label: 'Classification' },
        { key: 'language', label: 'Language' }
      ],
    };

    const attributeRefs = [
      {
        labelRef: firstLabel,
        valueRef: firstAttribute
      },
      {
        labelRef: secondLabel,
        valueRef: secondAttribute
      },
      {
        labelRef: thirdLabel,
        valueRef: thirdAttribute
      },
      {
        labelRef: fourthLabel,
        valueRef: fourthAttribute
      }
    ];

    function renderUI(data, currentCategory) {
      const keyValueMapByCategory = keyValueMap[currentCategory];

      keyValueMapByCategory.forEach((entry, index) => {
        const currentAttribute = attributeRefs[index];
        const [key, label] = entry;
        currentAttribute.labelRef = label;
        currentAttribute.valueRef = data[key];
      });
    }

    async function updateNextRecord() {
      const data = await getRecord(currentCategory, ++index);
      renderUI(data, currentCategory);
    }

    async function updatePreviousRecord() {
      const data = await getRecord(currentCategory, --index);
      renderUI(data, currentCategory)
      updatePrevBtnStatus();
    }

    function initializeCategory(catgeoryName) {
      currentCategory = catgeoryName;
      index = 0;
      updateNextRecord();
      updatePrevBtnStatus();
    }

    function updatePrevBtnStatus() {
      prevBtn.disabled = index === 1;
    }

    /* attach event listers*/
    //buttons
    nextBtn.addEventListener('click', function (e) {
      updateNextRecord();
    }, false)


    prevBtn.addEventListener('click', function (e) {
      updatePreviousRecord();
    }, false)

    //categories
    peopleCategory.addEventListener('click', function (e) {
      initializeCategory(e.target.value)
    }, false)

    planetCategory.addEventListener('click', function () {
      initializeCategory(e.target.value);
    }
      , false)

    speciesCategory.addEventListener('click', function () {
      initializeCategory(e.target.value);
    }
      , false)

    function init() {
      initializeCategory(currentCategory);
    }

    init();

  }
})(window, document, undefined);